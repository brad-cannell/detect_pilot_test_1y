library(testthat)
library(bfuncs)

test_check("bfuncs")
