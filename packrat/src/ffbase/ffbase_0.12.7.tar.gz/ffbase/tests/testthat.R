#library(ffbase)
library(testthat)

test_check("ffbase")