.onAttach <- function(lib,pkg)
{
   packageStartupMessage("RecordLinkage library")
   packageStartupMessage("[c] IMBEI Mainz\n")
}
