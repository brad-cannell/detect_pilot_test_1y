# register S3 classes so that they can be used for S4 method dispatching

setOldClass(c("RecLinkResult", "RecLinkData"))
setOldClass("RecLinkClassif")
